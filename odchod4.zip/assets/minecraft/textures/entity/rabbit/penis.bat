@echo off
for %%f in (rabbit_black.png rabbit_brown.png rabbit_caerbannog.png rabbit_gold.png rabbit_salt.png rabbit_toast.png rabbit_white.png rabbit_white_splotched.png) do (
    magick composite -gravity center overlay.png "%%f" "%%f"
)
echo Hotovo!
pause